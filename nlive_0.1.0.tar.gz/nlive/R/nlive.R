
#' Automated Estimation of Sigmoidal and Piecewise Linear Mixed Models
#'
#'
#'The nlive() function allows to fit a Sigmoidal Mixed Model with 4 parameters or a Piecewise Linear Mixed Model
#'with an abrupt or smooth transition in the context of longitudinal Gaussian outcomes. This function was designed to be
#'intuitive enough to the less sophisticated users, while using recent developments such as the
#'stochastic approximation expectation-maximization (SAEM) algorithm for efficient estimation. It was
#'designed to optimize the initial values of the main parameters and help
#'interpretation of the output by providing different features such as annotated outputs and graphs.
#'
#'
#' CAUTIONS REGARDING THE USE OF THE FUNCTION
#'
#' categorical covariates: there is currently no automated treatment of categorical covariates in the R package _saemix_, which is
#' used to fit the models. This can be circumvented by users creating sets of binary covariates
#'
#' traj.marg: if "TRUE", this argument automatically plots the estimated marginal trajectories of the longitudinal outcome
#' for the most common profile of covariates, if any (i.e., ref "1" for binary variables and mean values for continuous variables).
#' Thus, users must ensure that continuous variables are centered on the mean.
#'
#'
#' @param model indicator of the model to fit (1 for the Sigmoidal Mixed Model, 2 for the Piecewise Mixed Model with abrupt change, 3 for the Piecewise Mixed Model with smooth transition).
#' @param dataset data frame containing the variables ID, outcome, time, predictor.all, and predictor.par1 to predictor.par4. This data frame needs to be named "dataset" (see example below).
#' @param ID name of the variable representing the grouping structure specified with " (e.g., "ID" representing a unique identifier of participants).
#' @param outcome name of the time-varying variable representing the longitudinal outcome specified with " (e.g., "outcome").
#' @param time name of the variable representing the timescale specified with " (e.g., "time"). Can be negative or positive but model 1 will always report it as a positive value under the variable midpoint.
#' @param predictor.all optional vector indicating the name of the variable(s) that the four main parameters of the model of interest will be adjusted to. Default to NULL.
#' @param predictor.par1 optional vector indicating the name of the variable(s) that the first main parameter of the model of interest will be adjusted to. For model 1, the first parameter = last level. For models 2 and 3, first parameter = intercept. Default to NULL.
#' @param predictor.par2 optional vector indicating the name of the variable(s) that the second main parameter of the model of interest will be adjusted to. For model 1, the second parameter = initial level. For models 2 and 3, second parameter = slope before the change-point. Default to NULL.
#' @param predictor.par3 optional vector indicating the name of the variable(s) that the third main parameter of the model of interest will be adjusted to. For model 1, the third parameter = midpoint. For models 2 and 3, third parameter = slope after the change-point. Default to NULL.
#' @param predictor.par4 optional vector indicating the name of the variable(s) that the fourth main parameter of the model of interest will be adjusted to. For model 1, the fourth parameter = rate of change (Hill slope). For models 2 and 3, fourth parameter = change-point. Default to NULL.
#' @param start optional vector to specify manually the four initial values for the four main parameters. For model 1, the values must be included in the following order: last level, initial level, midpoint, rate of change. For models 2 and 3, the values must be included in the following order: intercept, slope before the change-point, slope after the change-point, change-point. Default to NULL.
#' @param traj.marg optional logical indicating if the marginal estimated trajectories should be plotted for the most common profile of covariates, if any. Default to FALSE.
#' @param plot.title optional text for the title of the spaghetti plot
#' @param plot.xlabel optional text for the title of the x-axis of all plots
#' @param plot.ylabel optional text for the title of the y-axis of all plots
#' @return No return values. However, the nlive function automatically provides several outputs, including (i) a spaghetti plot of the observed outcome for 70 statistical units randomly selected in _dataset_;
#' (ii) the standard saemix output, including estimates of the fixed effects, the variance of random effects, and Likelihood of the _model_ considered;
#' and (iii) a plot representing the estimated marginal trajectory of the outcome if argument _traj.marg_ is set to TRUE.
#' @author Maude Wagner, Ana W. Capuano, Emmanuelle Comets
#'
#' \email{maude_wagner@@rush.edu}
#'
#' @references
#'
#' The Sigmoidal mixed model formulation and computational methods are described in Capuano A, Wilson R, Leurgans S, Dawson J, Bennett D, Hedecker D (2018). Sigmoidal mixed models for longitudinal data. Statistical Methods in Medical Research, 27(3):863-875.
#' The Piecewise linear mixed model with abrupt and polynomial smooth change are described in van den Hout A, Muniz-Terrera G, Matthews F (2011). Smooth random change point models. Statistics in Medicine, 30(6):599-610.
#' The saemix R package and SAEM algorithm are described in Comets E, Lavenu A, Lavielle MM (2017). Parameter estimation in nonlinear mixed effect models using saemix, an R implementation of the SAEM algorithm. Journal of Statistical Software, 80(3):1-41.
#'
#' @examples
#' #### Existing R packages to download
#' library(saemix)
#' library(nlraa)
#' library(lcmm)
#' library(ggplot2)
#' library(dplyr)
#' library(sqldf)
#' library(knitr)
#' #### Fit a Sigmoidal Mixed Model with no covariate
#' \donttest{nlive(model=1, dataset=dataset, ID="ID", outcome="cogn", time="time")}
#' #### Fit a Picewise Mixed Model with abrupt change and all 4 parameters adjusted for sex
#' \donttest{nlive(model=2, dataset=dataset, ID="ID", outcome="cogn", time="time", predictor.all=c("male"))}
#' @export
#'
nlive <- function(model, dataset, ID, outcome, time, predictor.all = NULL, predictor.par1 = NULL, predictor.par2 = NULL, predictor.par3 = NULL, predictor.par4 = NULL, start = NULL, traj.marg = FALSE, plot.title = NULL, plot.xlabel = NULL, plot.ylabel = NULL){

  ## dataset
  dataset         = dataset
  dataset         = na.omit(dataset[,])
  dataset$ID      = dataset[,ID]
  dataset$outcome = dataset[,outcome]
  dataset$time    = dataset[,time]

  ## Values used throughout the code
  first    = as.data.frame(dataset %>% group_by(ID) %>% filter(row_number(ID) == 1))
  nb_indiv = dim(first)[1]
  nb_line  = dim(dataset)[1]
  nb_col   = dim(dataset)[2]

  ## total nb of -unique- covariates
  x          = unique(unlist(as.list(c(predictor.all, predictor.par1, predictor.par2, predictor.par3, predictor.par4))))
  nb_cov     = length(x)
  predictors = unique(x)


  #############################################
  ######          SPAGHETTI PLOT         ######
  ###### 70 indivudals randomly selected ######
  ######     (automatically generated)   ######
  #############################################

  if (is.null(plot.xlabel) == T){x.lab = time} else if (is.null(plot.xlabel) == F){x.lab = plot.xlabel}
  if (is.null(plot.ylabel) == T){y.lab = outcome} else if (is.null(plot.ylabel) == F){y.lab = plot.ylabel}
  if (is.null(plot.title)  == T){main.lab ="Spaghetti plot, random sample of 70 individuals"} else if (is.null(plot.title) == F){main.lab = plot.title}
  #c(x.lab,y.lab,main.lab)

  if (nb_indiv >= 70){

    ## Random selection of 70 individuals
    tempo1 = sample_n(first, 70)
    tempo2 = sqldf('SELECT * FROM dataset WHERE ID IN (SELECT ID FROM tempo1)')
    min    = min(tempo2[,time])
    max    = max(tempo2[,time])
    plot   = ggplot(tempo2, aes(time, outcome, group = ID, colour = factor(ID))) +
      geom_line(size=0.8) +
      scale_x_continuous(limits=c(min, max)) +
      guides(colour="none") +
      labs(x=x.lab, y=y.lab) +
      ggtitle(main.lab)
    print(plot)

  } else if (nb_indiv < 70){

    ## Random selection for the whole study sample
    tempo1 = sample_n(first, dim(first)[1])
    tempo2 = sqldf('SELECT * FROM dataset WHERE ID IN (SELECT ID FROM tempo1)')
    min    = min(tempo2[,time])
    max    = max(tempo2[,time])
    plot   = ggplot(tempo2, aes(time, outcome, group = ID, colour = factor(ID))) +
      scale_x_continuous(limits=c(min, max)) +
      guides(colour="none") +
      geom_line(size=0.8) +
      labs(x=x.lab, y=y.lab) +
      ggtitle("Spaghetti plot, whole sample")
    print(plot)
  }



  #####################################
  ######  SIGMOIDAL MIXED MODEL  ######
  #####################################
  if (model == 1){

    dataset$time_pos = abs(dataset[,time])

    ## STARTING VALUES  ##
    if (is.null(start) == T) {

      frag   = quantile(dataset$time, probs = c(0.2,0.4,0.6,0.8))
      # interval 1
      tab_int = subset(dataset, time <= frag[1])
      lmm    = hlme(outcome ~ 1 + time, random = ~1 + time, subject=ID, data=tab_int, verbose = F)
      slope1 = mean(coef(lmm)["time"])
      # interval 2
      tab_int = subset(dataset, time >= frag[1] & time <= frag[2])
      lmm  = hlme(outcome ~ 1 + time, random = ~1 + time, subject=ID, data=tab_int, verbose = F)
      slope2 = mean(coef(lmm)["time"])
      # interval 3
      tab_int = subset(dataset, time >= frag[2] & time <= frag[3])
      lmm  = hlme(outcome ~ 1 + time, random = ~1 + time, subject=ID, data=tab_int, verbose = F)
      slope3 = mean(coef(lmm)["time"])
      # interval 4
      tab_int = subset(dataset, time >= frag[3] & time <= frag[4])
      lmm  = hlme(outcome ~ 1 + time, random = ~1 + time, subject=ID, data=tab_int, verbose = F)
      slope4 = mean(coef(lmm)["time"])
      # interval 5
      tab_int = subset(dataset, time >= frag[4])
      lmm  = hlme(outcome ~ 1 + time, random = ~1 + time, subject=ID, data=tab_int, verbose = F)
      slope5 = mean(coef(lmm)["time"])
      ###
      y = c(slope1,slope2,slope3,slope4,slope5)
      val = min(y)
      pos = frag[which(y == val)-1]

      # last level (intercept)
      tempo   = subset(dataset, time > quantile(dataset$time, probs=c(0.97)))
      last.level  = mean(tempo[, outcome])
      # first level
      tempo   = subset(dataset, time < quantile(dataset$time, probs=c(0.05)))
      first.level  = mean(tempo[, outcome])
      ##
      tempo = subset(dataset, time_pos < -pos)
      lmm   = hlme(outcome ~ 1+time_pos, random =~1+time_pos, subject=ID, data=tempo, verbose = F)
      low   = as.numeric(coef(lmm)["time_pos"])
      ##
      tempo = subset(dataset, time_pos > -pos)
      lmm   = hlme(outcome ~ 1+time_pos, random =~1+time_pos, subject=ID, data=tempo, verbose = F)
      high  = as.numeric(coef(lmm)["time_pos"])
      c(low,high)
      ##
      midpoint   = ifelse(abs(low/high)> 0.5 & abs(low/high) < 1.5, 300, 2)
      hill.slope = ifelse(abs(low/high)> 0.5 & abs(low/high) < 1.5, 1.05, 0.5)

    } else if (length(start) == 4) {
      last.level  = start[1]
      first.level = start[2]
      midpoint    = start[3]
      hill.slope  = start[4]
    }
    c(last.level, first.level, midpoint, hill.slope)

    ## CORRELATION BETWEEN n1/n2 only ##
    varCov      = diag(0, ncol=4, nrow=4)
    varCov[1,1] = varCov[2,2] = varCov[1,2] = varCov[2,1] = 1     ##########   !!!!!!!!   #########

    ## SPECIFICATION OF THE MODEL ##
    model_fct = function(psi, ID, xidep){

      t           = xidep[, 1]

      last.level  = psi[ID, 1]
      first.level = psi[ID, 2]
      midpoint    = psi[ID, 3]
      hill.slope  = psi[ID, 4]

      t2 = abs(t)
      Y_pred = SSlogis5(t2, last.level, first.level, midpoint, hill.slope, theta = 1)

      return(Y_pred)
    }


    ## SPECIFICATION OF THE MATRIX OF COVARIATES ##

    if (nb_cov == 0) {

      mat_predictor = matrix(1, ncol=4, nrow=nb_cov)

    } else if (is.null(predictor.all)==F & nb_cov == length(predictor.all)){  ##!!!!!!!

      mat_predictor = matrix(1, ncol=4, nrow=nb_cov)

    } else if (is.null(predictor.all)==F & nb_cov != length(predictor.all)){

      mat.all = matrix(1, ncol=4, nrow=length(predictor.all))
      y = unique(unlist(as.list(predictor.all)))
      y = as.list(y)
      rownames(mat.all) = y
      mat.tempo = matrix(0, ncol=4, nrow=nb_cov-length(predictor.all))
      x = unique(unlist(as.list(c(predictor.par1, predictor.par2, predictor.par3, predictor.par4))))
      x = as.list(x)
      rownames(mat.tempo) = x

      for (i in 1:length(x)){
        if (isTRUE(x[i] %in% predictor.par1)){mat.tempo[i,1] = 1}
      }
      for (i in 1:length(x)){
        if (isTRUE(x[i] %in% predictor.par2)){mat.tempo[i,2] = 1}
      }
      for (i in 1:length(x)){
        if (isTRUE(x[i] %in% predictor.par3)){mat.tempo[i,3] = 1}
      }
      for (i in 1:length(x)){
        if (isTRUE(x[i] %in% predictor.par4)){mat.tempo[i,4] = 1}
      }
      mat_predictor = rbind(mat.all,mat.tempo)
    }

    ##
    saemix.model.cog = saemixModel(model = model_fct,
                                   psi0  = rbind(c(last.level  = last.level,
                                                   first.level = first.level,
                                                   midpoint    = midpoint,
                                                   hill.slope  = hill.slope),
                                                 matrix(0, ncol=4, nrow=1)),
                                   covariate.model  = mat_predictor,
                                   covariance.model = varCov,
                                   verbose = F)

    ##
    saemix.cog = saemixData(name.data       = dataset,
                            name.group      = ID,
                            name.predictors = time,
                            name.response   = outcome,
                            name.covariates = predictors,
                            verbose = F)
    ##
    saemix.options = saemixControl(map = F,
                                   nbiter.saemix = c(300,100), # nb of iterations for the exploration and smoothing phase
                                   nbiter.burn = 20,           # nb of iterations for burning
                                   nbiter.mcmc = c(5,5,5,0),   # nb of iterations in each kernel during the MCMC step
                                   ll.is = T,                  # default = T (TRUE) to estimate the log-likelihood
                                   seed = 123,
                                   displayProgress = F,        # default = T = to output the convergence plots
                                   save = F,                   # default = T = the results of the fit should be saved to a file
                                   save.graphs = F)            # default = T = to save the diagnostic and individual graphs


    ## fit
    ptm<-proc.time()
    model_SMM = saemix(saemix.model.cog, saemix.cog, saemix.options)
    cost<-proc.time()-ptm
    coef.SMM  = model_SMM@results@fixed.effects

    # calculation of p-values for the 4 parameters
    tab = cbind(c(model_SMM@results@name.fixed, "error"),
                c(round(model_SMM@results@fixed.effects,3), round(model_SMM@results@respar[model_SMM@results@indx.res],3)),
                c(round(model_SMM@results@se.fixed,3),round(model_SMM@results@se.respar[model_SMM@results@indx.res],3)))
    colnames(tab) = c("Parameter","Estimate","  SE")
    wstat = as.double(tab[,2])/as.double(tab[,3])
    pval  = rep(0, length(wstat))
    pval2 = round(1 - normcdf(abs(wstat[1:length(pval)])), 3)
    tab   = cbind(tab,"p-value" = pval2)
    tab = as.data.frame(tab)
    tab$`p-value` = ifelse(tab$`p-value` == "0", "P<.0001", tab$`p-value`)
    tab
    # output
    print(tab)
    cat("----------------------------------------------------\n The program took", round(cost[3],2), "seconds \n")

    if(traj.marg == TRUE){
      ##
      A     = coef.SMM[1]
      B     = coef.SMM[1*length(predictor.all)+length(predictor.par1) + 2]
      C     = coef.SMM[2*length(predictor.all)+length(predictor.par1)+length(predictor.par2) + 3]
      D     = coef.SMM[3*length(predictor.all)+length(predictor.par1)+length(predictor.par2)+length(predictor.par3) + 4]
      # marginal predictions
      if (mean(dataset[,time]) > 0){
        min_plot = round(quantile(dataset[,time], probs=c(0.01)),0)
        max_plot = round(quantile(dataset[,time], probs=c(0.90)),0)
        tab_SMM  = data.frame(time_pos = seq(min_plot, max_plot,0.1))
        tab_SMM$traj_SMM = SSlogis5(tab_SMM$time_pos, A, B, C, D, theta=1)

        plot(tab_SMM$time_pos, tab_SMM$traj_SMM,  las=1,
             lwd  = 3, type = "l",
             xlab = x.lab,  ylab = y.lab,
             main = "Marginal estimated trajectory",
             col  = "cyan4",
             legend = NULL)

      } else if (mean(dataset[,time]) < 0) {
        min_plot = round(quantile(dataset[,time], probs=c(0.1)),0)
        max_plot = round(quantile(dataset[,time], probs=c(0.99)),0)
        tab_SMM  = data.frame(time_neg = seq(min_plot, max_plot,0.1), time_pos = seq(-min_plot, max_plot,-0.1))
        tab_SMM$traj_SMM = SSlogis5(tab_SMM$time_pos, A, B, C, D, theta=1)

        plot(tab_SMM$time_neg, tab_SMM$traj_SMM,  las=1,
             lwd  = 4, type = "l",
             xlab = x.lab,  ylab = y.lab,
             main = "Marginal estimated trajectory",
             col  = "cyan4",
             legend = NULL)
      }
    }
  }

  ######################################
  ######  PIECEWISE MIXED MODELS  ######
  ######    (models in c(2,3)     ######
  ######################################

  if (model == 2) {
    ## SPECIFICATION - ABRUPT CHANGE ##
    model_fct = function(psi, ID, xidep){
      t           = xidep[, 1]
      last.level  = psi[ID, 1]
      slope1      = psi[ID, 2]
      slope2      = psi[ID, 3]
      changepoint = psi[ID, 4]
      I1 = as.numeric(t <= changepoint)
      I2 = as.numeric(t >  changepoint)
      Y_pred = I1*(last.level + slope2*changepoint + slope1*(t - changepoint)) + I2*(last.level + slope2*t)
      return(Y_pred)
    }
  } else if (model == 3) {
    ## SPECIFICATION - POLYNOMIAL SMOOTH TRANSITION ##
    model_fct = function(psi, ID, xidep){
      t           = xidep[, 1]
      last.level  = psi[ID, 1]
      slope1      = psi[ID, 2]
      slope2      = psi[ID, 3]
      changepoint = psi[ID, 4]
      transition  = 2
      I1 = as.numeric(t <= changepoint + transition/2)
      I2 = as.numeric(t >  changepoint + transition/2)
      Y_pred = I1*(last.level + slope2*(changepoint + transition/2) + slope1*(t - (changepoint + transition/2))) +I2*(last.level + slope2*t)
      return(Y_pred)
    }
  }


  if (model == 2 | model == 3) {

    ## CORRELATION BETWEEN n1/n2 only ##
    varCov      = diag(1, ncol=4, nrow=4)
    varCov[2,3] = varCov[3,2] = 1

    ## STARTING VALUES OF THE 4 PARAMETERS ##
    if (is.null(start) == T){

      frag   = quantile(dataset$time, probs = c(0.2,0.4,0.6,0.8))
      # interval 1
      tab_int = subset(dataset, time <= frag[1])
      lmm    = hlme(outcome ~ 1 + time, random = ~1 + time, subject=ID, data=tab_int, verbose = F)
      slope1 = mean(coef(lmm)["time"])
      # interval 2
      tab_int = subset(dataset, time >= frag[1] & time <= frag[2])
      lmm  = hlme(outcome ~ 1 + time, random = ~1 + time, subject=ID, data=tab_int, verbose = F)
      slope2 = mean(coef(lmm)["time"])
      # interval 3
      tab_int = subset(dataset, time >= frag[2] & time <= frag[3])
      lmm  = hlme(outcome ~ 1 + time, random = ~1 + time, subject=ID, data=tab_int, verbose = F)
      slope3 = mean(coef(lmm)["time"])
      # interval 4
      tab_int = subset(dataset, time >= frag[3] & time <= frag[4])
      lmm  = hlme(outcome ~ 1 + time, random = ~1 + time, subject=ID, data=tab_int, verbose = F)
      slope4 = mean(coef(lmm)["time"])
      # interval 5
      tab_int = subset(dataset, time >= frag[4])
      lmm  = hlme(outcome ~ 1 + time, random = ~1 + time, subject=ID, data=tab_int, verbose = F)
      slope5 = mean(coef(lmm)["time"])
      ###
      y = c(slope1,slope2,slope3,slope4,slope5)
      val = min(y)
      pos = frag[which(y == val)-1]

      # last level (intercept)
      tempo      = subset(dataset, time > quantile(dataset$time, probs=c(0.97))) #KEEP
      last.level = mean(tempo[, outcome])
      # first slope
      tempo  = subset(dataset, time < pos)
      m1     = hlme(outcome ~ 1 + time, random = ~1 + time, subject=ID, data=tempo, verbose = F)
      slope1 = mean(coef(m1)["time"])
      # second slope
      tempo  = subset(dataset, time > pos)
      m2     = hlme(outcome ~ 1 + time, random = ~1+time, subject=ID, data=tempo, verbose = F)
      slope2 = mean(coef(m2)["time"])
      # changepoint
      changepoint = mean(pos)
      c(last.level, slope1, slope2, changepoint)

    } else if (length(start) == 4) {
      last.level  = start[1]
      slope1      = start[2]
      slope2      = start[3]
      changepoint = start[4]
    }


    ## SPECIFICATION OF THE MATRIX OF COVARIATES ##

    if (nb_cov == 0) {

      mat_predictor = matrix(1, ncol=4, nrow=nb_cov)

    } else if (is.null(predictor.all)==F & nb_cov == length(predictor.all)){

      mat_predictor = matrix(1, ncol=4, nrow=nb_cov)

    } else if (is.null(predictor.all)==F & nb_cov != length(predictor.all)){

      mat.all = matrix(1, ncol=4, nrow=length(predictor.all))
      y = unique(unlist(as.list(predictor.all)))
      y = as.list(y)
      rownames(mat.all) = y
      mat.tempo = matrix(0, ncol=4, nrow=nb_cov-length(predictor.all))
      x = unique(unlist(as.list(c(predictor.par1, predictor.par2, predictor.par3, predictor.par4))))
      x = as.list(x)
      rownames(mat.tempo) = x

      for (i in 1:length(x)){
        if (isTRUE(x[i] %in% predictor.par1)){mat.tempo[i,1] = 1}
      }
      for (i in 1:length(x)){
        if (isTRUE(x[i] %in% predictor.par2)){mat.tempo[i,2] = 1}
      }
      for (i in 1:length(x)){
        if (isTRUE(x[i] %in% predictor.par3)){mat.tempo[i,3] = 1}
      }
      for (i in 1:length(x)){
        if (isTRUE(x[i] %in% predictor.par4)){mat.tempo[i,4] = 1}
      }
      mat_predictor = rbind(mat.all,mat.tempo)
    }

    ##
    saemix.model.cog = saemixModel(model = model_fct,
                                   psi0  = rbind(c(last.level  = last.level,
                                                   slope1      = slope1,
                                                   slope2      = slope2,
                                                   changepoint = changepoint),
                                                 matrix(0, ncol=4, nrow=1)),
                                   covariate.model  = mat_predictor,
                                   covariance.model = varCov,
                                   verbose = F)

    ##
    saemix.cog = saemixData(name.data       = dataset,
                            name.group      = ID,
                            name.predictors = time,
                            name.response   = outcome,
                            name.covariates = predictors,
                            verbose = F)
    ##
    saemix.options = saemixControl(map = F,
                                   nbiter.saemix = c(300,100), # nb of iterations for the exploration and smoothing phase
                                   nbiter.burn = 20,           # nb of iterations for burning
                                   nbiter.mcmc = c(5,5,5,0),   # nb of iterations in each kernel during the MCMC step
                                   ll.is = T,                  # default = T (TRUE) to estimate the log-likelihood
                                   seed = 123,
                                   displayProgress = F,        # default = T = to output the convergence plots
                                   save = F,                   # default = T = the results of the fit should be saved to a file
                                   save.graphs = F)            # default = T = to save the diagnostic and individual graphs

    ptm<-proc.time()
    ## fit using the estimation function saemix()
    model_PMM = saemix(saemix.model.cog, saemix.cog, saemix.options)
    cost<-proc.time()-ptm
    coef.PMM  = model_PMM@results@fixed.effects

    # calculation of p-values for the 4 parameters
    tab = cbind(c(model_PMM@results@name.fixed, "error"),
                c(round(model_PMM@results@fixed.effects,3), round(model_PMM@results@respar[model_PMM@results@indx.res],3)),
                c(round(model_PMM@results@se.fixed,3),round(model_PMM@results@se.respar[model_PMM@results@indx.res],3)))
    colnames(tab) = c("Parameter","Estimate","  SE")
    wstat = as.double(tab[,2])/as.double(tab[,3])
    pval  = rep(0, length(wstat))
    pval2 = round(1 - normcdf(abs(wstat[1:length(pval)])), 3)
    tab   = cbind(tab,"p-value" = pval2)
    tab = as.data.frame(tab)
    tab$`p-value` = ifelse(tab$`p-value` == "0", "P<.0001", tab$`p-value`)
    tab
    # output
    print(tab)
    cat("----------------------------------------------------\n The program took", round(cost[3],2), "seconds \n")


    ##########################################################
    ######   MARGINAL ESTIMATED TRAJECTORIES            ######
    ######   FOR THE MOST COMMON PROFILE OF COVARIATES  ######
    ##########################################################
    if(traj.marg == TRUE){
      if (mean(dataset[,time]) > 0){
        min_plot = round(quantile(dataset[,time], probs=c(0.01)),0)
        max_plot = round(quantile(dataset[,time], probs=c(0.90)),0)
      } else if (mean(dataset[,time]) < 0) {
        min_plot = round(quantile(dataset[,time], probs=c(0.1)),0)
        max_plot = round(quantile(dataset[,time], probs=c(0.99)),0)
      }
      tab_traj = data.frame(time = seq(min_plot, max_plot, 0.1),
                            ## parameters
                            last.level  = coef.PMM[1],
                            slope1      = coef.PMM[1*length(predictor.all)+length(predictor.par1) + 2],
                            slope2      = coef.PMM[2*length(predictor.all)+length(predictor.par1)+length(predictor.par2) + 3],
                            changepoint = coef.PMM[3*length(predictor.all)+length(predictor.par1)+length(predictor.par2)+length(predictor.par3) + 4],
                            ## transition parameter
                            transition = 2)

      n0 = tab_traj$last.level[1]
      n1 = tab_traj$slope1[1]
      n2 = tab_traj$slope2[1]
      n3 = tab_traj$changepoint[1]

      if (model == 2) {
        tab_traj$I1       = as.numeric(tab_traj$time <= tab_traj$changepoint)
        tab_traj$I2       = as.numeric(tab_traj$time >  tab_traj$changepoint)
        tab_traj$traj_PMM = tab_traj$I1*(n0 + n2*n3 + n1*(tab_traj$time - n3)) +
          tab_traj$I2*(n0 + n2*tab_traj$time)

      } else if (model == 3) {
        e  = tab_traj$transition[1]
        lambda = n0 + n2*(n3+e/2) - n1*(n3 + e/2)
        tab_traj$I1 = as.numeric(tab_traj$time <= tab_traj$changepoint)
        tab_traj$I2 = as.numeric(tab_traj$time >  tab_traj$changepoint & tab_traj$time < tab_traj$changepoint + 2)
        tab_traj$I3 = as.numeric(tab_traj$time >= tab_traj$changepoint + 2)

        # system of 4 linear equations with 4 unknown parameters
        A = matrix(c(n3^3, n3^2, n3, 1,
                     (n3+e)^3, (n3+e)^2, (n3+e), 1,
                     2*(n3^2), 2*n3, 1, 0,
                     2*((n3+e)^2), 2*(n3+e), 1, 0), ncol=4, byrow=T)
        B = matrix(c(n0+n2*(n3+e/2)-n1*(n3+e/2)+n1*n3,
                     n0+n2*(n3+e),
                     n1,
                     n2))
        mat = solve(A) %*% B

        tab_traj$traj_PMM =
          tab_traj$I1*(lambda+n1*tab_traj$time)+
          tab_traj$I2*(mat[1]*(tab_traj$time^3) + mat[2]*(tab_traj$time^2) + mat[3]*tab_traj$time + mat[4]) +
          tab_traj$I3*(n0+n2*tab_traj$time)
      }

      ## Plot
      plot(tab_traj$time, tab_traj$traj_PMM,
           lwd = 3, type = "l", las=1,
           xlim=c(min_plot, max_plot),
           xlab = x.lab,  ylab = y.lab,
           main = "Marginal estimated trajectory",
           col  = "cyan4",
           legend = NULL)
    }
  }
}


