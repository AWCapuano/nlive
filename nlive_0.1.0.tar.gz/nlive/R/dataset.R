#' Made-up longitudinal data on global cognition before death
#'
#' The dataset contains 1,200 individuals with one line per visit. Repeated measures
#' of global cognition (cogn) were collected over a maximum period of 30 years.
#' Time-independent socio-demographic information is also provided (age_bl, age_death,
#' education, male).
#'
#' @name dataset
#' @docType data
#' @format A data frame with 11,886 observations over 1,200 subjects and 11
#' variables: \describe{
#' \item{ID}{subject identification number}
#' \item{time}{the retrospective (negative) time before death (in years)}
#' \item{cogn}{composite score of global cognition}
#' \item{age}{age at the follow-up visit}
#' \item{age_bl}{age at baseline (in years)}
#' \item{age_bl80}{age at baseline centered by the mean}
#' \item{age_death}{age at death (in years)}
#' \item{age_death90}{age at death centered by the mean}
#' \item{education}{years of education}
#' \item{education17}{years of education centered by the mean}
#' \item{male}{binary indicator for sex (\code{male=1}
#' for men; \code{male=0} for women)} }
#' @keywords datasets
#' @examples
#'
#' summary(dataset)
#'
NULL
